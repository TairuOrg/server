--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 16.3
-- Dumped by pg_dump version 16.3

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE tairu_db;
--
-- Name: tairu_db; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE tairu_db WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'English_United States.1252';


ALTER DATABASE tairu_db OWNER TO postgres;

\connect tairu_db

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: administrators; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.administrators (
    id integer NOT NULL,
    personal_id character varying(10) NOT NULL,
    password character varying(256) NOT NULL,
    name character varying(70) NOT NULL,
    phone_number character varying(17) NOT NULL,
    email character varying(120) NOT NULL,
    residence_location character varying(50) NOT NULL
);


ALTER TABLE public.administrators OWNER TO postgres;

--
-- Name: administrators_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.administrators ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.administrators_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.items (
    id integer NOT NULL,
    barcode_id character varying(12),
    name character varying(70) NOT NULL,
    price numeric(4,2) NOT NULL,
    "category " character varying(25) NOT NULL,
    manufacturer character varying(70) NOT NULL,
    quantity integer NOT NULL
);


ALTER TABLE public.items OWNER TO postgres;

--
-- Name: articles_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.items ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.articles_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: cashier; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.cashier (
    id integer NOT NULL,
    personal_id character varying(10) NOT NULL,
    name character varying(70) NOT NULL,
    password character varying(256) NOT NULL,
    phone_number character varying(17) NOT NULL,
    email character varying(120) NOT NULL,
    residence_location character varying(50) NOT NULL
);


ALTER TABLE public.cashier OWNER TO postgres;

--
-- Name: cashier_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.cashier ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.cashier_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: customers; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.customers (
    id integer NOT NULL,
    name character varying(70) NOT NULL,
    personal_id character varying(10) NOT NULL,
    phone_number character varying(17) NOT NULL,
    residence_location character varying(50) NOT NULL
);


ALTER TABLE public.customers OWNER TO postgres;

--
-- Name: customers_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.customers ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.customers_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: entries; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.entries (
    id integer NOT NULL,
    admin_id integer NOT NULL,
    description text NOT NULL,
    date timestamp without time zone NOT NULL
);


ALTER TABLE public.entries OWNER TO postgres;

--
-- Name: entries_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.entries ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.entries_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: entries_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.entries_items (
    id integer NOT NULL,
    entry_id integer NOT NULL,
    item_id integer NOT NULL,
    quantity integer NOT NULL
);


ALTER TABLE public.entries_items OWNER TO postgres;

--
-- Name: entries_items_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.entries_items ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.entries_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.notifications (
    id integer NOT NULL,
    date timestamp without time zone NOT NULL,
    body_message character varying NOT NULL,
    priority_status character varying NOT NULL
);


ALTER TABLE public.notifications OWNER TO postgres;

--
-- Name: notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.notifications ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.notifications_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: reports; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.reports (
    id integer NOT NULL,
    admin_id integer NOT NULL,
    type character varying(25) NOT NULL,
    report_url character varying NOT NULL,
    date timestamp without time zone NOT NULL
);


ALTER TABLE public.reports OWNER TO postgres;

--
-- Name: reports_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.reports ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.reports_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: sales; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sales (
    id integer NOT NULL,
    cashier_id integer NOT NULL,
    customer_id integer NOT NULL,
    date timestamp without time zone NOT NULL
);


ALTER TABLE public.sales OWNER TO postgres;

--
-- Name: sales_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.sales ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.sales_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: sales_items; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sales_items (
    id integer NOT NULL,
    item_id integer NOT NULL,
    sale_id integer NOT NULL,
    quantity integer NOT NULL
);


ALTER TABLE public.sales_items OWNER TO postgres;

--
-- Name: sales_items_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.sales_items ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.sales_items_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: sent_notifications; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.sent_notifications (
    id integer NOT NULL,
    notification_id integer NOT NULL,
    admin_id integer NOT NULL,
    is_read boolean NOT NULL,
    is_ignored boolean NOT NULL
);


ALTER TABLE public.sent_notifications OWNER TO postgres;

--
-- Name: sent_notifications_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

ALTER TABLE public.sent_notifications ALTER COLUMN id ADD GENERATED ALWAYS AS IDENTITY (
    SEQUENCE NAME public.sent_notifications_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Data for Name: administrators; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.administrators (id, personal_id, password, name, phone_number, email, residence_location) FROM stdin;
\.
COPY public.administrators (id, personal_id, password, name, phone_number, email, residence_location) FROM '$$PATH$$/4931.dat';

--
-- Data for Name: cashier; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.cashier (id, personal_id, name, password, phone_number, email, residence_location) FROM stdin;
\.
COPY public.cashier (id, personal_id, name, password, phone_number, email, residence_location) FROM '$$PATH$$/4935.dat';

--
-- Data for Name: customers; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.customers (id, name, personal_id, phone_number, residence_location) FROM stdin;
\.
COPY public.customers (id, name, personal_id, phone_number, residence_location) FROM '$$PATH$$/4937.dat';

--
-- Data for Name: entries; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.entries (id, admin_id, description, date) FROM stdin;
\.
COPY public.entries (id, admin_id, description, date) FROM '$$PATH$$/4939.dat';

--
-- Data for Name: entries_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.entries_items (id, entry_id, item_id, quantity) FROM stdin;
\.
COPY public.entries_items (id, entry_id, item_id, quantity) FROM '$$PATH$$/4941.dat';

--
-- Data for Name: items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.items (id, barcode_id, name, price, "category ", manufacturer, quantity) FROM stdin;
\.
COPY public.items (id, barcode_id, name, price, "category ", manufacturer, quantity) FROM '$$PATH$$/4933.dat';

--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.notifications (id, date, body_message, priority_status) FROM stdin;
\.
COPY public.notifications (id, date, body_message, priority_status) FROM '$$PATH$$/4943.dat';

--
-- Data for Name: reports; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.reports (id, admin_id, type, report_url, date) FROM stdin;
\.
COPY public.reports (id, admin_id, type, report_url, date) FROM '$$PATH$$/4945.dat';

--
-- Data for Name: sales; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sales (id, cashier_id, customer_id, date) FROM stdin;
\.
COPY public.sales (id, cashier_id, customer_id, date) FROM '$$PATH$$/4947.dat';

--
-- Data for Name: sales_items; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sales_items (id, item_id, sale_id, quantity) FROM stdin;
\.
COPY public.sales_items (id, item_id, sale_id, quantity) FROM '$$PATH$$/4949.dat';

--
-- Data for Name: sent_notifications; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.sent_notifications (id, notification_id, admin_id, is_read, is_ignored) FROM stdin;
\.
COPY public.sent_notifications (id, notification_id, admin_id, is_read, is_ignored) FROM '$$PATH$$/4951.dat';

--
-- Name: administrators_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.administrators_id_seq', 1, false);


--
-- Name: articles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.articles_id_seq', 1, false);


--
-- Name: cashier_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.cashier_id_seq', 1, false);


--
-- Name: customers_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.customers_id_seq', 1, false);


--
-- Name: entries_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.entries_id_seq', 1, false);


--
-- Name: entries_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.entries_items_id_seq', 1, false);


--
-- Name: notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.notifications_id_seq', 1, false);


--
-- Name: reports_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.reports_id_seq', 1, false);


--
-- Name: sales_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sales_id_seq', 1, false);


--
-- Name: sales_items_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sales_items_id_seq', 1, false);


--
-- Name: sent_notifications_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.sent_notifications_id_seq', 1, false);


--
-- Name: administrators administrators_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.administrators
    ADD CONSTRAINT administrators_pkey PRIMARY KEY (id);


--
-- Name: items articles_pk; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.items
    ADD CONSTRAINT articles_pk PRIMARY KEY (id);


--
-- Name: cashier cashiers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cashier
    ADD CONSTRAINT cashiers_pkey PRIMARY KEY (id);


--
-- Name: customers customers_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT customers_pkey PRIMARY KEY (id);


--
-- Name: entries_items entries_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.entries_items
    ADD CONSTRAINT entries_items_pkey PRIMARY KEY (id);


--
-- Name: entries entries_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.entries
    ADD CONSTRAINT entries_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: customers phone_number_unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT phone_number_unique UNIQUE (phone_number);


--
-- Name: reports reports_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT reports_pkey PRIMARY KEY (id);


--
-- Name: sales_items sales_items_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_items
    ADD CONSTRAINT sales_items_pkey PRIMARY KEY (id);


--
-- Name: sales sales_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT sales_pkey PRIMARY KEY (id);


--
-- Name: sent_notifications sent_notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sent_notifications
    ADD CONSTRAINT sent_notifications_pkey PRIMARY KEY (id);


--
-- Name: administrators unique; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.administrators
    ADD CONSTRAINT "unique" UNIQUE (phone_number, email, personal_id);


--
-- Name: cashier unique2; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.cashier
    ADD CONSTRAINT unique2 UNIQUE (phone_number, email, personal_id);


--
-- Name: customers unique_personal_id; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.customers
    ADD CONSTRAINT unique_personal_id UNIQUE (personal_id);


--
-- Name: fki_admin_id_entries_fk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_admin_id_entries_fk ON public.entries USING btree (admin_id);


--
-- Name: fki_admin_id_reports_fk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_admin_id_reports_fk ON public.reports USING btree (admin_id);


--
-- Name: fki_admin_id_sent_notifications_fk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_admin_id_sent_notifications_fk ON public.sent_notifications USING btree (admin_id);


--
-- Name: fki_cashier_id_sales_fk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_cashier_id_sales_fk ON public.sales USING btree (cashier_id);


--
-- Name: fki_customer_id_sales_fk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_customer_id_sales_fk ON public.sales USING btree (customer_id);


--
-- Name: fki_e; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_e ON public.entries_items USING btree (item_id);


--
-- Name: fki_entry_id_entries_items_fk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_entry_id_entries_items_fk ON public.entries_items USING btree (entry_id);


--
-- Name: fki_item_id_sales_items_fk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_item_id_sales_items_fk ON public.sales_items USING btree (item_id);


--
-- Name: fki_notification_id_sent_notifications_fk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_notification_id_sent_notifications_fk ON public.sent_notifications USING btree (notification_id);


--
-- Name: fki_sale_id_sales_items_fk; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX fki_sale_id_sales_items_fk ON public.sales_items USING btree (sale_id);


--
-- Name: entries admin_id_entries_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.entries
    ADD CONSTRAINT admin_id_entries_fk FOREIGN KEY (admin_id) REFERENCES public.administrators(id);


--
-- Name: reports admin_id_reports_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.reports
    ADD CONSTRAINT admin_id_reports_fk FOREIGN KEY (admin_id) REFERENCES public.administrators(id);


--
-- Name: sent_notifications admin_id_sent_notifications_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sent_notifications
    ADD CONSTRAINT admin_id_sent_notifications_fk FOREIGN KEY (admin_id) REFERENCES public.administrators(id);


--
-- Name: sales cashier_id_sales_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT cashier_id_sales_fk FOREIGN KEY (cashier_id) REFERENCES public.cashier(id);


--
-- Name: sales customer_id_sales_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales
    ADD CONSTRAINT customer_id_sales_fk FOREIGN KEY (customer_id) REFERENCES public.customers(id);


--
-- Name: entries_items entry_id_entries_items_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.entries_items
    ADD CONSTRAINT entry_id_entries_items_fk FOREIGN KEY (entry_id) REFERENCES public.entries(id);


--
-- Name: entries_items item_id_entries_items_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.entries_items
    ADD CONSTRAINT item_id_entries_items_fk FOREIGN KEY (item_id) REFERENCES public.items(id);


--
-- Name: sales_items item_id_sales_items_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_items
    ADD CONSTRAINT item_id_sales_items_fk FOREIGN KEY (item_id) REFERENCES public.items(id);


--
-- Name: sent_notifications notification_id_sent_notifications_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sent_notifications
    ADD CONSTRAINT notification_id_sent_notifications_fk FOREIGN KEY (notification_id) REFERENCES public.notifications(id);


--
-- Name: sales_items sale_id_sales_items_fk; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.sales_items
    ADD CONSTRAINT sale_id_sales_items_fk FOREIGN KEY (sale_id) REFERENCES public.sales(id);


--
-- PostgreSQL database dump complete
--

